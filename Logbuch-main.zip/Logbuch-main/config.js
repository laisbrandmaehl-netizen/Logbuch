const APP_CONFIG = {
    validKeys: ["cskschlüssel"],
    allowedDomains: ["@cskiel.org"]
};
